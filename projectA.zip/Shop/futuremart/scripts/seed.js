require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../src/models/User');
const Product = require('../src/models/Product');
const Order = require('../src/models/Order');
const generateOrderNumber = require('../src/utils/generateOrderNumber');

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('🌱 Connected to MongoDB. Seeding...');

  // Clear existing data
  await Promise.all([User.deleteMany({}), Product.deleteMany({}), Order.deleteMany({})]);
  console.log('🗑️  Cleared existing data');

  // Create Admin
  const admin = await User.create({
    name: process.env.ADMIN_NAME || 'Admin',
    email: process.env.ADMIN_EMAIL || 'admin@futuremart.com',
    password: process.env.ADMIN_PASSWORD || 'Admin@123',
    role: 'admin',
  });
  console.log(`✅ Admin created: ${admin.email}`);

  // Create Vendors
  const vendor1 = await User.create({
    name: 'TechStore Vendor',
    email: 'techstore@futuremart.com',
    password: 'Vendor@123',
    role: 'vendor',
    vendorStatus: 'approved',
    businessName: 'TechStore India',
    businessDescription: 'Electronics and gadgets at best prices',
    phone: '9876543210',
  });

  const vendor2 = await User.create({
    name: 'Fashion Hub',
    email: 'fashionhub@futuremart.com',
    password: 'Vendor@123',
    role: 'vendor',
    vendorStatus: 'approved',
    businessName: 'Fashion Hub',
    businessDescription: 'Latest fashion trends for everyone',
    phone: '9876543211',
  });

  const pendingVendor = await User.create({
    name: 'Pending Vendor',
    email: 'pending@futuremart.com',
    password: 'Vendor@123',
    role: 'vendor',
    vendorStatus: 'pending',
    businessName: 'Pending Shop',
    phone: '9876543212',
  });

  console.log(`✅ Vendors created: ${vendor1.email}, ${vendor2.email}, ${pendingVendor.email}`);

  // Create Customers
  const customer1 = await User.create({
    name: 'Rahul Sharma',
    email: 'rahul@example.com',
    password: 'Customer@123',
    role: 'customer',
    phone: '9123456789',
    address: { street: '123 MG Road', city: 'Delhi', state: 'Delhi', pincode: '110001' },
  });

  const customer2 = await User.create({
    name: 'Priya Singh',
    email: 'priya@example.com',
    password: 'Customer@123',
    role: 'customer',
    phone: '9123456780',
    address: { street: '456 Park Street', city: 'Mumbai', state: 'Maharashtra', pincode: '400001' },
  });

  console.log(`✅ Customers created: ${customer1.email}, ${customer2.email}`);

  // Create Products (vendor1 - Electronics)
  const products = await Product.insertMany([
    {
      productName: 'Wireless Bluetooth Earphones',
      description: 'High quality wireless earphones with 20hr battery life and noise cancellation.',
      price: 2999,
      discountPrice: 2499,
      stock: 50,
      sku: 'TECH-EAR-001',
      category: 'Electronics',
      vendorId: vendor1._id,
      status: 'active',
    },
    {
      productName: 'USB-C Charging Hub 7-in-1',
      description: 'Multi-port USB-C hub compatible with all laptops. HDMI, USB 3.0, SD card reader.',
      price: 1999,
      discountPrice: 1599,
      stock: 30,
      sku: 'TECH-HUB-002',
      category: 'Electronics',
      vendorId: vendor1._id,
      status: 'active',
    },
    {
      productName: 'Mechanical Keyboard RGB',
      description: 'Tenkeyless mechanical keyboard with Cherry MX switches and RGB backlight.',
      price: 5999,
      stock: 15,
      sku: 'TECH-KB-003',
      category: 'Electronics',
      vendorId: vendor1._id,
      status: 'active',
    },
    // vendor2 - Fashion
    {
      productName: 'Premium Cotton T-Shirt',
      description: 'Comfortable 100% cotton t-shirt available in multiple colors.',
      price: 799,
      discountPrice: 599,
      stock: 100,
      sku: 'FASH-TSHIRT-001',
      category: 'Fashion',
      vendorId: vendor2._id,
      status: 'active',
    },
    {
      productName: 'Denim Slim Fit Jeans',
      description: 'Classic slim fit denim jeans, stretchable material.',
      price: 1499,
      discountPrice: 1199,
      stock: 60,
      sku: 'FASH-JEANS-002',
      category: 'Fashion',
      vendorId: vendor2._id,
      status: 'active',
    },
    {
      productName: 'Running Shoes Pro',
      description: 'Lightweight running shoes with extra cushioning.',
      price: 3499,
      discountPrice: 2999,
      stock: 0, // Out of stock
      sku: 'FASH-SHOE-003',
      category: 'Footwear',
      vendorId: vendor2._id,
      status: 'active',
    },
    {
      productName: 'Inactive Product Sample',
      description: 'This product is currently inactive and should not appear in customer listings.',
      price: 500,
      stock: 10,
      sku: 'INACT-001',
      category: 'Test',
      vendorId: vendor1._id,
      status: 'inactive',
    },
  ]);

  console.log(`✅ ${products.length} products created`);

  // Create a sample order
  const earphones = products[0];
  const tshirt = products[3];

  const order = await Order.create({
    orderNumber: generateOrderNumber(),
    customerId: customer1._id,
    items: [
      {
        productId: earphones._id,
        vendorId: vendor1._id,
        quantity: 2,
        priceAtPurchase: earphones.discountPrice,
        productName: earphones.productName,
      },
      {
        productId: tshirt._id,
        vendorId: vendor2._id,
        quantity: 1,
        priceAtPurchase: tshirt.discountPrice,
        productName: tshirt.productName,
      },
    ],
    totalAmount: earphones.discountPrice * 2 + tshirt.discountPrice,
    orderStatus: 'confirmed',
    paymentStatus: 'paid',
    address: {
      street: '123 MG Road',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
    },
  });

  console.log(`✅ Sample order created: ${order.orderNumber}`);

  console.log('\n🎉 Seeding complete!\n');
  console.log('=== LOGIN CREDENTIALS ===');
  console.log(`Admin:    admin@futuremart.com     / ${process.env.ADMIN_PASSWORD || 'Admin@123'}`);
  console.log('Vendor1:  techstore@futuremart.com / Vendor@123');
  console.log('Vendor2:  fashionhub@futuremart.com / Vendor@123');
  console.log('Customer: rahul@example.com         / Customer@123');
  console.log('=========================\n');

  await mongoose.disconnect();
  process.exit(0);
};

seed().catch((err) => {
  console.error('Seeding failed:', err);
  process.exit(1);
});
